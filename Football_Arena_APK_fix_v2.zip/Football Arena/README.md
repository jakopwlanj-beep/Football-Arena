# Football Arena — Android APK build

This archive keeps the original game files and adds a local python-for-android recipe for Pygame Community Edition (pygame-ce), which provides the `pygame` import used by the game.

## Build on GitHub Actions

1. Upload this ZIP to the root of the GitHub repository with the exact name `Football_Arena_GitHub_Actions.zip`, replacing the previous ZIP.
2. Open Actions and run **Build Football Arena APK** (or wait for the push-triggered run).
3. When the workflow succeeds, download the `football-arena-debug-apk` artifact and extract the APK.

The APK build has not been executed in this ChatGPT environment. A successful cross-build also needs to be tested on an Android device.
