[app]
title = Football Arena
package.name = footballarena
package.domain = org.fomc
source.dir = .
source.include_exts = py,txt,json,ogg,ttf,png,jpg,jpeg
source.exclude_dirs = .git,.github,.buildozer,bin,__pycache__
version = 0.8
requirements = python3,pygame-ce
p4a.local_recipes = ./p4a-recipes
orientation = landscape
fullscreen = 1

# Android
android.api = 35
android.minapi = 23
android.ndk = 25b
android.archs = arm64-v8a, armeabi-v7a
android.accept_sdk_license = True
android.allow_backup = True

# Build
[buildozer]
log_level = 2
warn_on_root = 1
